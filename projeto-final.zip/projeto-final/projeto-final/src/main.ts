import { app, BrowserWindow } from 'electron'
import { RelatorioIpc, RelatorioJanela } from './relatorios/RelatorioBackend'

class Aplicacao {
  private readonly relatorios = new RelatorioJanela()

  iniciar = (): void => {
    app.whenReady().then(() => {
      new RelatorioIpc().registrar()
      this.relatorios.abrir()

      app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) this.relatorios.abrir()
      })
    })

    app.on('window-all-closed', () => {
      if (process.platform !== 'darwin') app.quit()
    })
  }
}

new Aplicacao().iniciar()
